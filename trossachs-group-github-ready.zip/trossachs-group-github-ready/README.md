# Trossachs Group — GitHub Ready

This is a Vite + React portfolio designed so you can upload the project files directly to GitHub and connect the repository to Vercel.

## You do NOT need to run npm on your phone/computer

Upload the files to GitHub. When you import the repository into Vercel, Vercel installs dependencies and builds the site automatically.

### Vercel settings
Framework preset: Vite
Build command: `npm run build`
Output directory: `dist`

Vercel normally detects these automatically from package.json.

## Important
The site is a frontend portfolio. The Admin button intentionally does not pretend to be a secure CMS. A production admin system needs real authentication and persistent storage.

The contact form is also a frontend demonstration. Connect an email/API provider before using it for real submissions.

## Included
- Responsive premium portfolio
- Dark/light mode
- Mobile navigation
- Animated 3D-inspired hero
- Services
- Projects and project detail modal
- Process section
- Contact form UI
- No external image assets required
- Vercel/GitHub friendly structure
